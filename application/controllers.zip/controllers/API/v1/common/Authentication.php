
<?php


require APPPATH . 'libraries/REST_Controller.php';

class Authentication extends REST_Controller
{

    public function __construct()
    {

        parent::__construct();
        $this->load->model('AuthenticationModel');
    }

    public function index_post()
    {

        try {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            if ($email != "" && $password != "") {
                $data = array(
                    "email" => $email,
                    "password" => md5($password),
                );
                $profiledata = $this->AuthenticationModel->auth($data);
                if ($profiledata == NOT_APPROVED) {
                    $this->response(array(
                        "status" => NOT_APPROVED,
                        "message" => NOT_APPROVED_MESSAGE,
                    ), REST_Controller::HTTP_OK);
                } elseif ($profiledata == NOT_VERIFY) {
                    $this->response(array(
                        "status" => NOT_VERIFY,
                        "message" => NOT_VERIFY_MESSAGE,
                    ), REST_Controller::HTTP_OK);
                } elseif ($profiledata == REJECTED) {
                    $this->response(array(
                        "status" => REJECTED,
                        "message" => REJECTED_MESSAGE,
                    ), REST_Controller::HTTP_OK);
                } elseif ($profiledata != "") {
                    $this->response(array(
                        "status" => DATA_AVAILABLE,
                        "message" => DATA_AVAILABLE_MESSAGE,
                        "data" => $profiledata
                    ), REST_Controller::HTTP_OK);
                } else {
                    $this->response(array(
                        "status" => DATA_NOT_AVAILABLE,
                        "message" => DATA_NOT_AVAILABLE_MESSAGE,
                        "data" => $profiledata
                    ), REST_Controller::HTTP_OK);
                }
            } else {
                $this->response(array(
                    "status" => "REQUIRED_FIELDS",
                    "message" => "REQUIRED_FIELDS_MESSAGE"
                ), REST_Controller::HTTP_OK);
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }
}

?>