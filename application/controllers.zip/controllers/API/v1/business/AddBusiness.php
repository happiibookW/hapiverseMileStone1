
<?php


require APPPATH . 'libraries/REST_Controller.php';

class AddBusiness extends REST_Controller
{

    public function __construct()
    {

        parent::__construct();
        $this->load->model('BusinessModel');
    }

    public function index_post()
    {

        try {

            $businessName = $this->input->post('businessName');
            $businessEmail = $this->input->post('businessEmail');
            $ownerName = $this->input->post('ownerName');
            $vatNo = $this->input->post('vatNo');
            if ($businessName != "" && $ownerName != "") {
                ////! Check Email Available in user Master Table
                    
                    $businessData = array(
                        "businessName" => $businessName,
                        "businessEmail" => $businessEmail,
                        "ownerName" => $ownerName,
                        "vatNo" => $vatNo,
                    );


                    if ($this->BusinessModel->insert($businessData, "mstbusiness") == true) {
                        #sendMail($email,'verfication COde',$verficationCode);
                        $this->response(array(
                            "status" => DATA_SAVE,
                            "message" => DATA_SAVE_MESSAGE
                        ), REST_Controller::HTTP_OK);
                    } else {
                        $this->response(array(
                            "status" => DATA_SAVE_ERROR,
                            "message" => DATA_SAVE_MESSAGE
                        ), REST_Controller::HTTP_OK);
                    }
            } else {
                $this->response(array(
                    "status" => REQUIRED_FIELDS,
                    "message" => REQUIRED_FIELDS_MESSAGE
                ), REST_Controller::HTTP_OK);
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }
}

?>