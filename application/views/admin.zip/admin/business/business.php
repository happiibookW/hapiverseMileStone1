<div class="content-header row">
            <div class="content-header-left col-md-9 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h2 class="content-header-title float-left mb-0">Businesses</h2>

                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <section class="invoice-list-wrapper">
                <div class="card">
                    <div class="card-datatable table-responsive">
                        <table class=" table businessdatatable" id="businessTable">
                            <thead>
                                <tr>
                                  
                                    <th>Business Name</th>
                                    <th>Owner Name</th>
                                    <th>Email</th>
                                    <th>Vat Number</th>
                                    <th>Country</th>
                                    <th>Action</th>
                                    
                                </tr>
                            </thead>
                            <tbody> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

        </div>