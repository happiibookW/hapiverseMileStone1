<?php
include 'config.php';
include 'sendEmail.php';
 if(isset($_POST)){
    
    $filename=$_FILES["file"]["tmp_name"];
    // echo "<pre>";
    // // print_r($_POST['subject']);
    // // print_r($_POST['message']);
    // print_r($_FILES);
    // echo "</pre>";
    // exit;
     $countfiles = count($_FILES['attachfiles']['name']);       
     if($_FILES["file"]["size"] > 0)
     {
        $file = fopen($filename, "r");
        fgets($file);
        $arr=array();
        $arr2=array();
        $i=0;
        $filename=array();
          while (($getData = fgetcsv($file, 1000, ",")) !== FALSE)
           {
            $sql = "INSERT into employeeinfo (firstname,lastname,email,reg_date) 
                     values ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."')";
                     $result = mysqli_query($con, $sql);
                     // $arr[]=$getData[2];
                     // $arr2[]=$getData[0]." ".$getData[1];
                     // $_FILES['attachfiles']['name'][$index]
                     // foreach($_FILES['attachfiles'] as $position => $file)
                     // {
                     // // if($_FILES['upload'][$position]['error'] != “0”)
                        
                        // $path="";    
                        for($index = 0;$index < $countfiles;$index++){
                          $name=$_FILES['attachfiles']['name'][$index];
                          $path=$_FILES['attachfiles']['tmp_name'][$index];
                          move_uploaded_file($_FILES["attachfiles"]["tmp_name"][$index],"upload/" . time().$_FILES["attachfiles"]["name"][$index]);
                          $filename[] = "upload/" . time().$_FILES["attachfiles"]["name"][$index];
                        }
                          sendEmail(array($getData[2]),array($getData[0]." ".$getData[1]),$_POST['subject'],$_POST['message'],$filename);
                     //     //And attach it using attachment method of PHPmailer.
                     //     $mail->addattachment($path,$name);
                     // }
                     
                   

        if(!isset($result))
        {
          echo "30";   
        }
        else {
            echo json_encode($i);
        }
        $i++;
        }
        fclose($file);  
     }
  }   
 ?>