$(document).ready(function () {
  $('#attachfiles').change(function (e) {
    // var names = [];
    for (var i = 0; i < $(this).get(0).files.length; ++i) {
      var fileItem = '<li class="list-item"><p class="file-title">'+ $(this).get(0).files[i].name +'</p></li>';
      
      $("#fileNamesList").append(fileItem);

    }
    // $("input[name=file]").val(names);

    // var fileName = e.target.files[0].name;
    // $("#fileNames").text(names + " uploaded");
  });
});
