<?php
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;

function sendEmail($email,$fullname,$subject,$message,$name){
   foreach ($email as $key => $value) {
      $mail = new PHPMailer;
      $mail->isSMTP();
      $mail->SMTPDebug = 2;
      $mail->Host = 'parking-eco.com';
      $mail->Port = 465;
      $mail->SMTPAuth = true;
      $mail->Username = 'bulkemails@parking-eco.com';
      $mail->Password = 'Biyl-9X9)dgq';
      $mail->setFrom('bulkemails@parking-eco.com', 'Testing');
      $mail->AddAddress($value, 'Testing');
      foreach ($name as $key => $value1) {
         $mail->addattachment($value1);
      }
      
      $mail->Subject = $subject;
      $mail->Body = $message;
      if($mail->send()){
         return "";
      }
   }
}
   
?>