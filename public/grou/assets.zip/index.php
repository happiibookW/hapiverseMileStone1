<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/aos.css">
    <link rel="stylesheet" href="assets/scss/style.css">

    <title>Document</title>
</head>
<style>
#myProgress {
  width: 100%;
  background-color: #ddd;
}

#myBar {
  width: 1%;
  height: 30px;
  background-color: #ee0041;
}
</style>
<body>
    <div class="background"></div>
    <div class="main">
        <div class="main-content">
            <!-- <div class="progress" style="display: none;">
                <div class="progress-bar" role="progressbar" aria-label="Basic example" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
            </div> -->
            <div id="myProgress" style="display: none;">
              <div id="myBar"></div>
            </div>
            <form method="POST" enctype="multipart/form-data">
            <section class="uploader">
                <div class="w-100">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 offset-lg-3">
                                <div class="card uploader-wrapper" data-aos="zoom-in" data-aos-delay="500">
                                        <div class="input-wrapper">
                                            <label for="fileUploader" class="form-label">
                                                <div class="d-flex align-items-center flex-column">
                                                    <div class="uploader-icon">
                                                        <img src="assets/img/svg/uload-ico.svg" alt="">
                                                    </div>
                                                    Drag and Drop CSV File Here
                                                </div>
                                            </label>
                                            <input type="file" id="fileUploader" class="form-control d-none" accept=".csv">
                                        </div>
                                    <!-- </form> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="email-composer" style="display: none;">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 offset-lg-3">
                            <div class="card" data-aos="zoom-in" data-aos-duration="500">
                                <div class="card-body">
                                    <ul class="files-list">
                                        <li class="list-items">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center gap-4">
                                                    <img class="file-ico" src="assets/img/svg/file-csv-ico.svg" alt="" data-aos="flip-left" data-aos-delay="300">
                                                    <div>
                                                        <h1 class="file-title" data-aos="fade-right" data-aos-delay="400"></h1>
                                                        <p class="card-text file-size"  data-aos="fade-right" data-aos-delay="600"></p>
                                                    </div>
                                                </div>
                                                <a href="" class="remove-btn"  data-aos="zoom-in" data-aos-delay="800"><img src="assets/img/svg/close-btn.svg" alt=""></a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card" data-aos="zoom-in" data-aos-duration="500" data-aos-delay="300">
                                <div class="card-body">
                                    <!-- <form method="POST"> -->
                                        <div class="input-wrapper" >
                                            <input type="text" id="subject" class="form-control" placeholder="Subject" name="subject">
                                        </div>
                                        <div class="input-wrapper">
                                            <textarea class="form-control" name="" id="message" rows="10" placeholder="Type your message here" name="message"></textarea>
                                        </div>
                                        <div class="input-wrapper">
                                            <label for="attachfiles" class="form-label custom-label">
                                                <img src="assets/img/svg/file-light.svg" alt="">
                                                <span class="ms-2">Attach files Here</span>
                                            </label>
                                            <input type="file" id="attachfiles" class="form-control d-none" multiple>
                                        </div>
                                        <div class="input-wrapper mb-3">
                                            <ol class="file-names-list" id="fileNamesList"></ul>
                                        </div>
                                        <button type="submit" class="btn btn-primary w-100 Import" name="Import">Post</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            </form>
        </div>
    </div>
    
    <div class="modal fade" id="success" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="successLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content card">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <div class="card-body">
                <div class="text-center">
                    <img src="assets/img/svg/check-dark.svg" alt="" class="card-img">
                    <h3 class="card-title">Emails Sent Successfully</h3>
                    <!-- <div class="card-text">Email sent to 102 contacts</div> -->
                </div>
            </div>
          </div>
        </div>
      </div>
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/aos.js"></script>
    <script src="assets/js/custom.js"></script>
    <script>
        AOS.init();
    </script>
</body>
</html>
<script type="text/javascript">
    function formatBytes(bytes, decimals = 2) {
        if (!+bytes) return '0 Bytes'

        const k = 1024
        const dm = decimals < 0 ? 0 : decimals
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']

        const i = Math.floor(Math.log(bytes) / Math.log(k))

        return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`
    }
    var i = 0;
    function move() {
      if (i == 0) {
        i = 1;
        var elem = document.getElementById("myBar");
        var width = 1;
        var id = setInterval(frame, 10);
        function frame() {
          if (width >= 100) {
            clearInterval(id);
            $('#myProgress').hide();
            i = 0;
          } else {
            width++;
            elem.style.width = width + "%";
          }
        }
      }
    }
    $('#fileUploader').change(function(e) { 
        if( document.getElementById("fileUploader").value.toLowerCase().lastIndexOf(".csv")==-1) 
        {
                alert("Please upload a file with .csv extension.");
                return false;
        }else{
            // console.log(formatBytes(e.target.files[0].size));
            $('.email-composer').show();
            $('.uploader').hide();
            $('.file-title').html(e.target.files[0].name);
            $('.file-size').html(formatBytes(e.target.files[0].size));  
        }
    });
    $('.remove-btn').click(function(){
        $('.email-composer').hide();
        $('.uploader').show();  
        $('.file-title').html('');
        $('.file-size').html('');
    });

    $('.btn-close').click(function(){
        // $('.email-composer').hide();
        // $('.uploader').show();  
        // $('.file-title').html('');
        // $('.file-size').html('');
        window.location.href="/";
    });

    $('form').submit(function(e){
        e.preventDefault();
        $('#myProgress').show();
        $('#subject').attr('disabled',true);
        $('#message').attr('disabled',true);
        $('.Import').attr('disabled',true);
        var property = document.getElementById('fileUploader').files[0];
        var subject = $('#subject').val();
        var message = $('#message').val();
        var totalfiles = document.getElementById('attachfiles').files.length;
        // console.log(property);
        // $("#last_file").html(property);
        var form_data = new FormData();
        form_data.append("file",property);
        form_data.append("subject",subject);
        form_data.append("message",message);
        for (var index = 0; index < totalfiles; index++) {
          form_data.append("attachfiles[]", document.getElementById('attachfiles').files[index]);
        }
        $.ajax({
          url:'functions.php',
          method:'POST',
          data:form_data,
          contentType:false,
          cache:false,
          processData:false,
        //   beforeSend:function(){
        //     // $('#msg').html('Loading......');
        //   },
          success:function(data){
            move();
            console.log(data);
            $('#success').modal('show');
            // if (i == 0) {
            //     i = 1;
            //     var elem = document.getElementById("progress-bar");
            //     var width = 1;
            //     var id = setInterval(frame, 10);
            //     function frame() {
            //       if (width >= 100) {
            //         clearInterval(id);
            //         i = 0;
            //       } else {
            //         width++;
            //         elem.style.width = width + "%";
            //       }
            //     }
            //   }
            // $('.progress').hide();
        //     // $('#msg').html(data);
        //     $('form').submit();
        //     // window.location.href="email-composer.php";
          }
        });
    })
</script>