<?php
echo "<pre>";
print_r($_FILES);
echo "</pre>";
exit;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/aos.css">
    <link rel="stylesheet" href="assets/scss/style.css">

    <title>Document</title>
</head>

<body>
    <div class="background"></div>
    <div class="main">
        <div class="main-content">
            <section class="email-composer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 offset-lg-3">
                            <div class="card" data-aos="zoom-in" data-aos-duration="500">
                                <div class="card-body">
                                    <ul class="files-list">
                                        <li class="list-items">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center gap-4">
                                                    <img class="file-ico" src="assets/img/svg/file-csv-ico.svg" alt="" data-aos="flip-left" data-aos-delay="300">
                                                    <div>
                                                        <h1 class="file-title" data-aos="fade-right" data-aos-delay="400"><?php echo $_FILES["file"]["name"] ?></h1>
                                                        <p class="card-text"  data-aos="fade-right" data-aos-delay="600">2.2mb, 102 contacts</p>
                                                    </div>
                                                </div>
                                                <a href="" class="remove-btn"  data-aos="zoom-in" data-aos-delay="800"><img src="assets/img/svg/close-btn.svg" alt=""></a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card" data-aos="zoom-in" data-aos-duration="500" data-aos-delay="300">
                                <div class="card-body">
                                    <form action="">
                                        <div class="input-wrapper" >
                                            <input type="text" id="subject" class="form-control" placeholder="Subject">
                                        </div>
                                        <div class="input-wrapper">
                                            <textarea class="form-control" name="" id="" rows="10" placeholder="Type your message here"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary w-100">Post</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>


    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>