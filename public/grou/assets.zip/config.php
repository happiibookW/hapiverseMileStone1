<?php
$servername = "localhost";
$username = "parkwjfz_bulkemails";
$password = "Biyl-9X9)dgq";
$db = "parkwjfz_bulkemails";
try {
   
    $con = mysqli_connect($servername, $username, $password, $db);
     // echo "Connected successfully"; 
    }
catch(exception $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
    return $con;
?>